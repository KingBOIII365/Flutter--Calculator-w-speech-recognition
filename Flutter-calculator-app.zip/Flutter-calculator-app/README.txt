This is a speech to text Calaculator app performed in Andriod Studio using Flutter. 
The code is stored in .dart format in "lib" folder.