import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'theme.dart';
import 'calculator_screen.dart';
import 'package:dcdg/dcdg.dart';
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();  // Initialize Hive
  await Hive.openBox<String>('calculation_history'); // Open Hive box

  runApp(
    ChangeNotifierProvider(
      create: (_) => ThemeProvider(),
      child: const MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);

    return MaterialApp(
      theme: themeProvider.currentTheme,
      home: const CalculatorScreen(),
    );
  }
}

class ThemeProvider extends ChangeNotifier {
  bool _isDarkMode = false;
  Color _secondaryColor = Colors.red;

  bool get isDarkMode => _isDarkMode;
  Color get secondaryColor => _secondaryColor;

  ThemeData get currentTheme {
    if (_isDarkMode) {
      return AppThemes.darkTheme;
    }
    return AppThemes.whiteAndBlue;
  }

  void toggleTheme() {
    _isDarkMode = !_isDarkMode;
    notifyListeners();
  }

  void changeTheme(int index) {
    switch (index) {
      case 0:
        _isDarkMode = false;
        _secondaryColor = Colors.blue;
        break;
      case 1:
        _isDarkMode = false;
        _secondaryColor = Colors.orange;
        break;
      case 2:
        _isDarkMode = true;
        _secondaryColor = Colors.green;
        break;
      case 3:
        _isDarkMode = true;
        _secondaryColor = Colors.red;
        break;
    }
    notifyListeners();
  }
}
