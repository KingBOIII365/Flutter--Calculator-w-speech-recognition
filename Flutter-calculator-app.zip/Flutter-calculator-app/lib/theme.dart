import 'package:flutter/material.dart';

class AppThemes {
  static final lightTheme = ThemeData(
    brightness: Brightness.light,
    primaryColor: Colors.white,
    scaffoldBackgroundColor: Colors.white,
    buttonTheme: ButtonThemeData(
      buttonColor: Colors.white, // Default color for buttons
    ),
    colorScheme: ColorScheme.light().copyWith(secondary: Colors.blue),  // Use secondary color
  );

  static final darkTheme = ThemeData(
    brightness: Brightness.dark,
    primaryColor: Colors.black,
    scaffoldBackgroundColor: Colors.black,
    buttonTheme: ButtonThemeData(
      buttonColor: Colors.black, // Default color for buttons
    ),
    colorScheme: ColorScheme.dark().copyWith(secondary: Colors.red),  // Use secondary color
  );

  static final whiteAndBlue = ThemeData(
    primaryColor: Colors.white,
    scaffoldBackgroundColor: Colors.white,
    buttonTheme: ButtonThemeData(
      buttonColor: Colors.white,
    ),
    colorScheme: ColorScheme.light().copyWith(secondary: Colors.blue),  // Use secondary color
  );

  static final whiteAndOrange = ThemeData(
    primaryColor: Colors.white,
    scaffoldBackgroundColor: Colors.white,
    buttonTheme: ButtonThemeData(
      buttonColor: Colors.white,
    ),
    colorScheme: ColorScheme.light().copyWith(secondary: Colors.orange),  // Use secondary color
  );

  static final blackAndGreen = ThemeData(
    primaryColor: Colors.black,
    scaffoldBackgroundColor: Colors.black,
    buttonTheme: ButtonThemeData(
      buttonColor: Colors.black,
    ),
    colorScheme: ColorScheme.dark().copyWith(secondary: Colors.green),  // Use secondary color
  );

  static final blackAndRed = ThemeData(
    primaryColor: Colors.black,
    scaffoldBackgroundColor: Colors.black,
    buttonTheme: ButtonThemeData(
      buttonColor: Colors.black,
    ),
    colorScheme: ColorScheme.dark().copyWith(secondary: Colors.red),  // Use secondary color
  );
}
