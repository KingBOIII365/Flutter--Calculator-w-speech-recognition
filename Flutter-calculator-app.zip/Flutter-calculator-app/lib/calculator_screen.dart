import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:hive/hive.dart';
import 'package:math_expressions/math_expressions.dart';
import 'main.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

class CalculatorScreen extends StatefulWidget {
  const CalculatorScreen({super.key});

  @override
  State<CalculatorScreen> createState() => _CalculatorScreenState();
}

class _CalculatorScreenState extends State<CalculatorScreen> {
  String _input = '';
  List<String> _history = [];
  bool _showHistory = false;
  bool _showThemes = false;
  late stt.SpeechToText _speech;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _loadHistory();
    _speech = stt.SpeechToText();
  }

  void _loadHistory() async {
    final box = Hive.box<String>('calculation_history');
    final historyString = box.get('history', defaultValue: '');
    setState(() {
      _history = historyString!.isNotEmpty ? historyString.split('|') : [];
    });
  }

  void _saveHistory() async {
    final box = Hive.box<String>('calculation_history');
    box.put('history', _history.join('|'));
  }

  void _onButtonPressed(String label) {
    setState(() {
      if (label == 'C') {
        _input = '';
      } else if (label == '=') {
        _calculateResult();
      } else if (label == '%') {
        _calculatePercentage();
      } else if (label == '⌫') {
        if (_input.isNotEmpty) {
          _input = _input.substring(0, _input.length - 1);
        }
      } else if (label == '( )') {
        _handleParentheses();
      } else {
        _input += label == 'x' ? '*' : label;
      }
    });
  }

  void _handleParentheses() {
    int openCount = _input.split('(').length - 1;
    int closeCount = _input.split(')').length - 1;

    // If the input is empty or ends with an operator, add '('
    if (_input.isEmpty || RegExp(r'[+\-*/^]$').hasMatch(_input)) {
      _input += '(';
    }
    // If open parentheses are more than close, add ')'
    else if (openCount > closeCount) {
      _input += ')';
    }
    // Otherwise, insert '()' and place the cursor inside
    else {
      _input += '()';
    }

    setState(() {
      _input = _input;
    });
  }


  void _calculatePercentage() {
    try {
      double value = double.parse(_input);
      setState(() {
        _input = (value / 100).toString();
      });
    } catch (e) {
      setState(() {
        _input = 'Error';
      });
    }
  }

  void _calculateResult() {
    try {
      String expression = _input.replaceAll('%', '/100');
      Parser parser = Parser();
      Expression exp = parser.parse(expression);
      ContextModel contextModel = ContextModel();
      double result = exp.evaluate(EvaluationType.REAL, contextModel);

      setState(() {
        _history.insert(0, '$_input = $result');
        if (_history.length > 14) _history.removeLast();
        _input = result.toString();
      });
      _saveHistory();
    } catch (e) {
      setState(() {
        _input = 'Error';
      });
    }
  }
  void _startListening() async {
    bool available = await _speech.initialize();
    if (available) {
      setState(() => _isListening = true);
      _speech.listen(onResult: (result) {
        setState(() {
          _input = result.recognizedWords.replaceAll('x', '*');
        });
      });
    }
  }

  void _stopListening() {
    _speech.stop();
    setState(() => _isListening = false);
  }
  // Toggle between showing history or themes
  void _toggleHistory() {
    setState(() {
      _showHistory = !_showHistory;
      _showThemes = false; // Hide themes when history is shown
    });
  }

  void _toggleThemes() {
    setState(() {
      _showThemes = !_showThemes;
      _showHistory = false; // Hide history when themes are shown
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Calculator'),
        actions: [
          IconButton(
            icon: const Icon(Icons.mic),
            onPressed: _isListening ? _stopListening : _startListening,
          ),
          IconButton(
            icon: const Icon(Icons.history),
            onPressed: _toggleHistory,
          ),
          IconButton(
            icon: const Icon(Icons.color_lens),
            onPressed: _toggleThemes,
          ),
        ],
      ),
      body: Column(
        children: <Widget>[
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(16),
              alignment: Alignment.bottomRight,
              child: Text(
                _input,
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: isDarkMode ? Colors.white : Colors.black,
                ),
              ),
            ),
          ),
          _showHistory
              ? _buildHistoryList()
              : _showThemes
              ? _buildThemeList(themeProvider) // Pass themeProvider here
              : Container(),
          _buildButtonRow(['C', '(  )', '%', '/']),
          _buildButtonRow(['7', '8', '9', 'x']),
          _buildButtonRow(['4', '5', '6', '-']),
          _buildButtonRow(['1', '2', '3', '+']),
          _buildButtonRow(['', '0', '=', '⌫']),
        ],
      ),
    );
  }

  Widget _buildButtonRow(List<String> buttons) {
    return Row(
      children: buttons.map((label) => _buildButton(label)).toList(),
    );
  }

  Widget _buildButton(String label) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    // Default button color
    Color buttonColor = themeProvider.isDarkMode ? Colors.grey[800]! : Colors.grey[300]!;

    // Apply secondary color to specific buttons
    if (['/', 'x', '-', '+', '⌫', 'C', '(  )', '%'].contains(label)) {
      buttonColor = themeProvider.secondaryColor;
    }

    return Expanded(
      child: GestureDetector(
        onTap: () => _onButtonPressed(label),
        child: Container(
          margin: const EdgeInsets.all(8),
          height: 60,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: buttonColor,
            borderRadius: BorderRadius.circular(8),
          ),
          child: Text(
            label,
            style: TextStyle(
              fontSize: 24,
              color: isDarkMode ? Colors.white : Colors.black,
            ),
          ),
        ),
      ),
    );
  }


  // Display History
  Widget _buildHistoryList() {
    return Expanded(
      child: ListView.builder(
        itemCount: _history.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(
              _history[index],
              style: TextStyle(
                color: Theme.of(context).brightness == Brightness.dark
                    ? Colors.white
                    : Colors.black,
              ),
            ),
          );
        },
      ),
    );
  }

  // Display Theme options
  Widget _buildThemeList(ThemeProvider themeProvider) {
    return Expanded(
      child: ListView.builder(
        itemCount: 4,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('Theme ${index + 1}'),
            onTap: () {
              themeProvider.changeTheme(index);
            },
          );
        },
      ),
    );
  }
}
